from flask import Flask, render_template
import os
from chart_generator import generate_charts

app = Flask(__name__)

@app.route('/')
def index():
    bar_charts = [f'static/images/bar_chart_{i + 1}.svg' for i in range(5)]  # Замените на актуальный список
    pie_charts = [f'static/images/pie_chart_{i + 1}.svg' for i in range(5)]  # Замените на актуальный список
    return render_template('index.html', bar_charts=bar_charts, pie_charts=pie_charts)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=1156)
