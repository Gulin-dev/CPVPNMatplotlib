from flask import Flask, render_template
import os
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from matplotlib import colormaps

output_folder = "static/images"
os.makedirs(output_folder, exist_ok=True)

data_file = 'vpn-rf.xlsx'
excel_reader = pd.ExcelFile(data_file, engine='openpyxl')
df1 = excel_reader.parse('Обзор рынка', index_col=None, header=None)
df2 = excel_reader.parse('Опрос компаний', index_col=None, header=None)

app = Flask(__name__)


def split_df(df):
    odf, ndf = [], []
    df_name, years = '', []
    temp_df, is_df = None, False

    for _, row in df.iterrows():
        if pd.notna(row[0]) and pd.isna(row[1]) and pd.isna(row[2]):
            if is_df:
                if years:
                    temp_df.columns = years
                odf.append(temp_df)
                ndf.append(df_name)
            df_name = row[0]
            temp_df, years = pd.DataFrame(), []
            is_df = True
            continue

        if row.isna().all():
            continue

        if is_df and pd.isna(row[0]) and pd.notna(row[1]):
            row[0] = 0
            years = row.dropna().astype(int).tolist()
            continue

        if is_df:
            temp_df = pd.concat([temp_df, pd.DataFrame([row.values])], ignore_index=True)

    if is_df:
        if years:
            temp_df.columns = years
        odf.append(temp_df)
        ndf.append(df_name)

    return odf, ndf


def make_pie(df, filename):
    fig, ax = plt.subplots(figsize=(6, 6))
    color_map = colormaps.get_cmap("viridis")
    colors = [color_map(i / len(df[1])) for i in range(len(df[1]))]

    ax.pie(
        x=np.array(df[1]),
        labels=np.array(df[0]),
        startangle=90,
        autopct='%1.2f%%',
        pctdistance=0.80,
        wedgeprops={'width': 0.40, 'edgecolor': 'w', 'linewidth': 3},
        textprops={'fontsize': 8},
        colors=colors
    )
    plt.savefig(filename, format='svg', dpi=400, bbox_inches='tight', pad_inches=0)
    plt.close()


def make_bar_chart(df, filename):
    x_labels = df.columns[1:]
    y_values = [df.iloc[i][1:].tolist() for i in range(len(df))]
    names = df.iloc[:, 0].tolist()

    num_categories = len(names)
    width = 0.8 / num_categories
    x = np.arange(len(x_labels))

    fig, ax = plt.subplots(figsize=(10, 5))
    color_map = colormaps.get_cmap("plasma")

    for i in range(num_categories):
        color = color_map(i / num_categories)
        ax.bar(x + i * width, y_values[i], width, label=names[i], color=color)

    ax.set_xticks(x + width * (num_categories - 1) / 2)
    ax.set_xticklabels(x_labels)
    ax.legend()
    plt.savefig(filename, format='svg', dpi=200, bbox_inches='tight', pad_inches=0)
    plt.close()


odf1, ndf1 = split_df(df1)
odf2, ndf2 = split_df(df2)

for i in range(len(odf1)):
    make_bar_chart(odf1[i], f'{output_folder}/bar_chart_{i + 1}.svg')

for i in range(len(odf2)):
    make_pie(odf2[i], f'{output_folder}/pie_chart_{i + 1}.svg')


@app.route('/')
def index():
    bar_charts = [f'static/images/bar_chart_{i + 1}.svg' for i in range(len(odf1))]
    pie_charts = [f'static/images/pie_chart_{i + 1}.svg' for i in range(len(odf2))]

    return render_template('index.html', bar_charts=bar_charts, pie_charts=pie_charts)


if __name__ == '__main__':
    app.run(debug=True)